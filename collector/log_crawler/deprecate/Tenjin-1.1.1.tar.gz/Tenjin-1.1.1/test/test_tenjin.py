###
### $Release: 1.1.1 $
### $Copyright: copyright(c) 2007-2012 kuwata-lab.com all rights reserved. $
###
from oktest import ok, not_ok, run, spec
from oktest.helper import dummy_file
import sys, os, re

import tenjin
from tenjin.helpers import *


class TenjinTest(object):

    pass



if __name__ == '__main__':
    run()
