items = [
   "AAA",
   123,
   True,
]
